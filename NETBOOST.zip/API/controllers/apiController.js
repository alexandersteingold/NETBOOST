const mongoose = require("mongoose");
const axios = require('axios');
const cheerio = require('cheerio');
const db = process.env.MONGODB_URI;
const MAX_URLS = process.env.MAX_URLS;
mongoose
    .connect(db, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log("MongoDB Connected"))
    .catch((err) => console.log(err));

// const urlSchema = new mongoose.Schema({
//     url: String,
//     depth: Number,
//     parent: mongoose.Schema.Types.ObjectId,
// });

const websiteSchema = new mongoose.Schema({
    url: String
});

const urlSchema = new mongoose.Schema({
    url: String,
    depth: Number,
    parent: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'WEBSITE'
    }
});

const WEBSITE = mongoose.model('WEBSITE', websiteSchema);
const URL = mongoose.model('URL', urlSchema);

const scrapeWebsite = async (url) => {
    try {
        const response = await axios.get(url);
        if (response.status === 200) {
            const html = response.data;
            const $ = cheerio.load(html);
            const links = $('a');
            const urls = [];

            $(links).each((i, link) => {
                urls.push($(link).attr('href'));
            });
            return urls;
        }
    } catch (err) {
        console.error(err);
    }
};



async function scrapeData(url, depth, parent, visited = new Set(), count = 0) {
    if (visited.has(url) || depth < 0 || count >= MAX_URLS) return;
    try {
        const urls = await scrapeWebsite(url);
        const absoluteUrls = urls
            .map((link) => {
                if (link && (link.startsWith('/') || link.startsWith('#'))) {
                    return `${url}${link}`;
                }
                return link;
            })
            .filter((link) => link && link.startsWith('http'));

        for (const url of absoluteUrls) {
            if (count >= MAX_URLS) break; // stop scraping if maximum number of URLs is reached
            const urlExists = await URL.exists({ url });
            if (!urlExists) {
                const newURL = new URL({ url, depth, parent });
                await newURL.save();
                count++; // increment count when a new URL is saved
            }
            await scrapeData(url, depth - 1, parent, visited, count);
        }
    } catch (err) {
        console.error(`Error scraping urls: ${url}`, err);
    }
}


exports.run = async (req, res) => {
    const { url, depth } = req.body;
    let parent = null;
    try {
        const urlExists = await WEBSITE.exists({ url });
        if (!urlExists) {
            const newWebsite = new WEBSITE({ url });
            await newWebsite.save();
            parent = newWebsite._id;
            await scrapeData(url, depth, parent);
        } else {
            parent = await WEBSITE.find({ url: url }, '_id');
        }
        let urls = await getUrls(parent);
        if (urls)
            res.json({ urls: urls.map(url => ({ url: url.url, depth: url.depth, depth: url.parent })) });
        // res.status(200).send({ message: 'Scraping successfuly completed' });
    } catch (err) {
        res.status(500).send({ error: err.message });
    }
}

async function getUrls(parentId) {
    try {

        const urls = await URL.find({ parent: parentId }, 'url depth parent -_id');
        return urls;
    } catch (err) {
        //res.status(500).send({ error: err.message });
        console.log(err.message);
    }
}
