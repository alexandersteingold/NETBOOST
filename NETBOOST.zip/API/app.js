const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const dotenv = require('dotenv').config();
const routes = require("./routes/apiRoutes");
const port = process.env.PORT || 5000;
const clientsApiKey = process.env.API_KEY;
const HeaderAPIKeyStrategy = require('passport-headerapikey').HeaderAPIKeyStrategy;
const passport = require('passport');

const app = express();
passport.use(new HeaderAPIKeyStrategy(
    { header: 'API-Key', prefix: '' },
    false,
    function (apiKey, done) {
        if (apiKey === clientsApiKey) {
            return done(null, true);
        }
        return done(null, false);
    }
));
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: false }));
app.use(cors({
    origin: '*'
}));
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));
app.use("/api", routes);
app.listen(port, () => console.log(`Server started on port ${port}`));