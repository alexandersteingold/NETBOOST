const express = require('express')
const router = express.Router();
const passport = require('passport');
const apiController = require('../controllers/apiController');

router.post('/run', passport.authenticate('headerapikey', { session: false }), apiController.run);
module.exports = router;