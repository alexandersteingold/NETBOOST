import { Component, ViewChild } from '@angular/core';
import { ApiService } from './api.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  formData: any = {
    url: '',
    depth: 0
  };
  urls: any[] = [];
  loading = false;
  noresults = false;
  submitted = false;
  @ViewChild('crawlerForm') crawlerForm: any;

  constructor(private apiService: ApiService) { }

  ngOnInit(): void { }

  onSubmit() {
    this.submitted = true;
    if (this.crawlerForm.invalid) {
      return;
    }
    this.loading = true;
    this.noresults = false;
    this.urls = [];
    this.formData.url = this.formData.url.replace(/^(http:\/\/|https:\/\/)/, '');
    this.formData.url = 'http://' + this.formData.url
    let url = new URL(this.formData.url);
    let strippedUrl = url.hostname.replace(/^(www\.)/, '');
    let parts = strippedUrl.split('.');
    if (parts.length > 2) {
      strippedUrl = parts.slice(parts.length - 2).join('.');
    }
    this.formData.url = strippedUrl;
    this.apiService.crawlWebsite('http://' + this.formData.url, this.formData.depth)
      .subscribe((response: any) => {
        this.urls = response['urls'];
        if (!this.urls.length) this.noresults = true;
        this.loading = false;
      },
        (err) => {
          console.error('Error crawling website:', err);
          this.loading = false;
        }
      );
  }
}
