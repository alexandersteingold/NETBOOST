
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http'
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Url } from './url';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private baseUrl = 'http://localhost:3000/api';
  private readonly headers = new HttpHeaders({
    'API-Key': environment.apiKey
  });

  constructor(private http: HttpClient) { }

  crawlWebsite(url: string, depth: number): Observable<Url[]> {
    const body = { url, depth };
    return this.http.post<Url[]>(`${this.baseUrl}/run`, body, { headers: this.headers });
  }


  getUrls(): Observable<Url[]> {
    return this.http.get<Url[]>(`${this.baseUrl}/urls`, { headers: this.headers });
  }

  refreshUrls(): Observable<Url[]> {
    return this.http.put<Url[]>(`${this.baseUrl}/urls`, { headers: this.headers });
  }
}