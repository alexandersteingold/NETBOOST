export interface Url {
    url: string;
    depth: number;
}